Thank you being a participant in my final year project on binaural audio.

The purpose of this project is to judge whether people are able to localise binaural or stereo audio more effectively. 
The software is audio focused, and audio only after the four initial calibration sounds. Please ensure your computer volume is at a comfortable level before starting the application.

The usage of this software requires a Nintendo Switch Right Joycon and headphones.

Setup:

- Connect the RIGHT Nintendo Joycon via Bluetooth by holding the small circular pairing button on the rail side of the Joycon.
- Hold the Joycon, IR sensor-up with the buttons facing towards the screen, then run the application. 
- Enter your name in the participant name box. Your name will be redacted from the final document, it is only needed here to differentiate each participant.
- Once your name has been confirmed the calibration mode will start.

Calibration mode:

- If the view is not moving with the Joycon, ensure the Joycon is still connected and restart the application.
- Either rest the Joycon on your forehead or rotate until you are centred on a green/blue sphere. This is how the localised sound should sound.
- Once you are adjusted to how the localised sound sounds, press the SPACE key to move onto the next sound. There are four calibration sounds in total.
- After each sound, move the Joycon back to the its original orientation and pressed the R key to reset any drifting which may have occurred, giving it a moment to return to the centre.
- Once you have submitted the fourth sound, you will move onto the main test.
 
Main Test:

- The visual indicators for the sounds are now hidden are you must move the Joycon to the sounds using only the audio cues.
- There are ten sound sources in total, it is recommended to reset the Joycon orientation after each sound like in calibration mode, if you encountered drifting during the calibration mode.
- Try to localise each sound as quickly as possible as the time to localise will be recorded.

Completion:
- Once you have completed all ten audio sources you will return to the name page. You can retry the test again if you wish (using the same name will override the previous data) or quit the application.
- Navigate to the "ParticipantFiles" folder and send the "yourname.csv" file back to the sender of this application.

Notes:
- Avoid over-rotating the Joycon (spinning it fully in any axis) during the test as this can cause the head-tracking to become incorrect even after recentring